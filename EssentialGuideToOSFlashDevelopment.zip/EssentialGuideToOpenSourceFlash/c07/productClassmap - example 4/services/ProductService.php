<?php
require_once "./vo/ProductVO.php";

class ProductService {
	var $dbh;
	
	public function __construct() {
		$this->dbh = mysql_connect ("localhost", "username", "password") or die ('I cannot connect to the database because: ' . mysql_error());
		mysql_select_db ("t8edgec_product");
	}
	
	function getProducts() {
		return mysql_query(sprintf("SELECT * FROM Product"));
	}
	
	function getProduct($Product_ID) {
		$sql = "SELECT * FROM Product where Product_ID ='$Product_ID'";
    	return mysql_query($sql);
	}
	
	function removeProduct($Product_ID) {
		$sql = "DELETE FROM Product WHERE Product_ID='$Product_ID'";
		return mysql_query($sql);
	}
	
	function updateProduct($Product_ID,$Name,$Category,$Image, $Price, $Description, $Qty_In_Stock) {
		$sql = "UPDATE Product SET PRODUCT_ID='$Product_ID',NAME='$Name',CATEGORY='$Category',IMAGE='$Image', PRICE='$Price', DESCRIPTION='$Description', QTY_IN_STOCK='$Qty_In_Stock' WHERE PRODUCT_ID=$Product_ID";
		return mysql_query($sql);		 
	}
	
	function addProduct($Name,$Category,$Image, $Price, $Description, $Qty_In_Stock) {
		$sql = "INSERT INTO Product (Name,Category,Image, Price, Description, Qty_In_Stock) VALUES ('$Name','$Category','$Image', '$Price', '$Description', '$Qty_In_Stock')";
		return mysql_query($sql);
	}
	
	function getProductVO() {
		$myProducts = array();	
		$sql = "SELECT * FROM Product";
		$result = mysql_query($sql);
		
		while($row = mysql_fetch_array($result))
		{
			$product = new ProductVO();
			$product->productId = $row['PRODUCT_ID'];
			$product->name = $row['NAME'];
			$product->description = $row['DESCRIPTION'];
			$product->image = $row['IMAGE'];
			$product->category = $row['CATEGORY'];
			$product->price = $row['PRICE'];
			$product->qtyInStock = $row['QTY_IN_STOCK'];
			$myProducts[] = $product;
		}  
    	return $myProducts;
	}
}
?>