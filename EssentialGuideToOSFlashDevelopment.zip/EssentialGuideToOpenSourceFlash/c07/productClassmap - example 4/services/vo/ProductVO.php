<?php
class ProductVO {
    var $productId;
    var $name;
    var $description;
    var $image;
	var $category;
	var $price;
	var $qtyInStock;
    // explicit actionscript package
    var $_explicitType = "ProductVO";
}
?>