<?php
class HelloWorld
{
    function say($sMessage)
    {
    	$date = getdate();
        return 'You said: ' . $sMessage .' on '.$date[weekday];
    }    
}
?>