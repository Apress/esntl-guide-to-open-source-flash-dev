
--
-- Table structure for table `Product`
--

CREATE TABLE `Product` (
  `PRODUCT_ID` int(11) NOT NULL auto_increment,
  `NAME` varchar(40) NOT NULL default '',
  `CATEGORY` varchar(40) NOT NULL default '',
  `IMAGE` varchar(40) NOT NULL default '',
  `PRICE` double NOT NULL default '0',
  `DESCRIPTION` varchar(255) NOT NULL default '',
  `QTY_IN_STOCK` int(11) NOT NULL default '0',
  PRIMARY KEY  (`PRODUCT_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=22 ;

--
-- Dumping data for table `Product`
--

INSERT INTO `Product` VALUES(1, 'Nokia 6100', '6000', 'Nokia_6010.gif', 99, 'Easy to use without sacrificing style, the Nokia 6010 phone offers functional voice communication supported by text messaging, multimedia messaging, mobile internet, games and more.', 5);
INSERT INTO `Product` VALUES(2, 'Nokia 3100 Blue', '9000', 'Nokia_3100_blue.gif', 109, 'Light up the night with a glow-in-the-dark cover - when it is charged with light you can easily find your phone in the dark. When you get a call, the Nokia 3100 phone flashes in tune with your ringing tone. And when you snap on a Nokia Xpress-on gaming co', 99);
INSERT INTO `Product` VALUES(3, 'Nokia 3100 Pink', '3000', 'Nokia_3100_pink.gif', 139, 'Light up the night with a glow-in-the-dark cover - when it is charged with light you can easily find your phone in the dark. When you get a call, the Nokia 3100 phone flashes in tune with your ringing tone. And when you snap on a Nokia Xpress-on gaming co', 30);
INSERT INTO `Product` VALUES(4, 'Nokia 3650', '3000', 'Nokia_3650.gif', 200, 'Messaging is more personal, versatile and fun with the Nokia 3650 camera phone.  Capture experiences as soon as you see them and send the photos you take to you friends and family.', 11);
INSERT INTO `Product` VALUES(5, 'Nokia 6820', '6000', 'Nokia_6820.gif', 299.99, 'Messaging just got a whole lot smarter. The Nokia 6820 messaging device puts the tools you need for rich communication - full messaging keyboard, digital camera, mobile email, MMS, SMS, and Instant Messaging - right at your fingertips, in a small, sleek d', 8);
INSERT INTO `Product` VALUES(6, 'Nokia 6670', '6000', 'Nokia_6670.gif', 319.99, 'Classic business tools meet your creative streak in the Nokia 6670 imaging smartphone. It has a Netfront Web browser with PDF support, document viewer applications for email attachments, a direct printing application, and a megapixel still camera that als', 10);
INSERT INTO `Product` VALUES(7, 'Nokia 6620', '6000', 'Nokia_6620.gif', 329.99, 'Shoot a basket. Shoot a movie. Video phones from Nokia... the perfect way to save and share life�s playful moments. Feel connected.', 10);
INSERT INTO `Product` VALUES(8, 'Nokia 3230 Silver', '3000', 'Nokia_3230_black.gif', 500, 'Get creative with the Nokia 3230 smartphone. Create your own ringing tones, print your mobile images, play multiplayer games over a wireless Bluetooth connection, and browse HTML and xHTML Web pages.', 9);
INSERT INTO `Product` VALUES(9, 'Nokia 3120', '3000', 'Nokia_3120.gif', 159.99, 'Designed for both business and pleasure, the elegant Nokia 3120 phone offers a pleasing mix of features. Enclosed within its chic, compact body, you will discover the benefits of tri-band compatibility, a color screen, MMS, XHTML browsing, cheerful screen', 10);
INSERT INTO `Product` VALUES(10, 'Nokia 3220', '3000', 'Nokia_3220.gif', 199, 'The Nokia 3220 phone is a fresh new cut on some familiar ideas - animate your MMS messages with cute characters, see the music with lights that flash in time with your ringing tone, download wallpapers and screensavers with matching color schemes for the', 20);
INSERT INTO `Product` VALUES(11, 'Nokia 6680', '6000', 'Nokia_6680.gif', 222, 'The Nokia 6680 is an imaging smartphone that', 36);
INSERT INTO `Product` VALUES(12, 'Nokia 6630', '6000', 'Nokia_6630.gif', 379, 'The Nokia 6630 imaging smartphone is a 1.3 megapixel digital imaging device (1.3 megapixel camera sensor, effective resolution 1.23 megapixels for image capture, image size 1280 x 960 pixels).', 11);
INSERT INTO `Product` VALUES(13, 'Nokia 7610 Black', '7000', 'Nokia_7610_black.gif', 450, 'The Nokia 7610 imaging phone with its sleek, compact design stands out in any crowd. Cut a cleaner profile with a megapixel camera and 4x digital zoom. Quality prints are all the proof you need of your cutting edge savvy.', 20);
INSERT INTO `Product` VALUES(14, 'Nokia 7610 White', '7000', 'Nokia_7610_white.gif', 4500, 'The Nokia 7610 imaging phone with its sleek, compact design stands out in any crowd. Cut a cleaner profile with a megapixel camera and 4x digital zoom. Quality prints are all the proof you need of your cutting edge savvy.', 7);
INSERT INTO `Product` VALUES(15, 'Nokia 6680', '6000', 'Nokia_6680.gif', 219, 'The Nokia 6680 is an imaging smartphone.', 15);
INSERT INTO `Product` VALUES(16, 'Nokia 9300', '9000', 'Nokia_9300_close.gif', 599, 'The Nokia 9300 combines popular voice communication features with important productivity applications in one well-appointed device. Now the tools you need to stay in touch and on top of schedules, email, news, and messages are conveniently at your fingert', 26);
INSERT INTO `Product` VALUES(17, 'Nokia 9500', '9000', 'Nokia_9500_close.gif', 799.99, 'Fast data connectivity with Wireless LAN. Browse the Internet in full color, on a wide, easy-to-view screen. Work with office documents not just email with attachments and memos, but presentations and databases too.', 54);
INSERT INTO `Product` VALUES(18, 'Nokia N90', '9000', 'Nokia_N90.gif', 499, 'Twist and shoot. It is a pro-photo taker. A personal video-maker. Complete with Carl Zeiss Optics for crisp, bright images you can view, edit, print and share. Meet the Nokia N90.', 12);
INSERT INTO `Product` VALUES(19, 'Wade', '6000', 'coolio.gif', 99, 'this is one of the best phones ever!', 33);
